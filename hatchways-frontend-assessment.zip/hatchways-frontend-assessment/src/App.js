import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Students from './components/Students';
import './App.css';

function App() {
  return (
    <div className="App">
      <Students />
    </div>
  );
}

export default App;
